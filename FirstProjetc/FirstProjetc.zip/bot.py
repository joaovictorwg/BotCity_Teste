"""
WARNING:

Please make sure you install the bot with `pip install -e .` in order to get all the dependencies
on your Python environment.

Also, if you are using PyCharm or another IDE, make sure that you use the SAME Python interpreter
as your IDE.

If you get an error like:
```
ModuleNotFoundError: No module named 'botcity'
```

This means that you are likely using a different Python interpreter than the one used to install the bot.
To fix this, you can either:
- Use the same interpreter as your IDE and install your bot with `pip install --upgrade -r requirements.txt`
- Use the same interpreter as the one used to install the bot (`pip install --upgrade -r requirements.txt`)

Please refer to the documentation for more information at https://documentation.botcity.dev/
"""

# Import for the Desktop Bot
from botcity.core import DesktopBot

# Import for integration with BotCity Maestro SDK
from botcity.maestro import *

# Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

from botcity.core import DesktopBot, Backend

def main():
    # Runner passes the server url, the id of the task being executed,
    # the access token and the parameters that this task receives (when applicable).
    maestro = BotMaestroSDK.from_sys_args()
    ## Fetch the BotExecution with details from the task, including parameters
    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")

    bot = DesktopBot()

    app_path = "C:/Users/jvict/OneDrive/Documentos/Programas-Jogos/Teams_windows_x64.exe"
    bot.execute(app_path)
    bot.connect_to_app(backend=Backend.UIA, path=app_path)
    
    bot.wait(10)
    #Procurar por Nome
    if not bot.find( "profile_anchor", matching=0.97, waiting_time=10000):
        not_found("profile_anchor")
    bot.click_relative(-704, 21)
    
    
    bot.paste("Danilo Ferreira de Cássia")
    bot.key_enter

    #Clicar no contato
    if not bot.find( "contato", matching=0.97, waiting_time=10000):
        not_found("contato")
    bot.click()
    

    
    #Digitar Mensagem
    if not bot.find( "Icons", matching=0.97, waiting_time=10000):
        not_found("Icons")
    bot.click_relative(131, -31)
    
    bot.paste("Olá, sou um Bot Criado em python utilizando BotCity.\n Meu Código está no repositório: ")


def not_found(label):
    print(f"Element not found: {label}")


if __name__ == '__main__':
    main()

