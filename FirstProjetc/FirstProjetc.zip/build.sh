#!/bin/bash

zip -r "FirstProjetc.zip" * -x "FirstProjetc.zip"